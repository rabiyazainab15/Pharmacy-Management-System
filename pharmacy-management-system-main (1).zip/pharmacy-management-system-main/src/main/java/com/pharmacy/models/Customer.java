package com.pharmacy.models;

import java.io.Serializable;

public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int customerId;
    private String name;
    private String phone;
    private String email;
    private String address;
    private int totalPurchases;
    private double totalSpent;
    private long createdAt;

    public Customer(int customerId, String name, String phone, String email, String address) {
        this.customerId = customerId;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.totalPurchases = 0;
        this.totalSpent = 0.0;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and Setters
    public int getCustomerId() { return customerId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public int getTotalPurchases() { return totalPurchases; }
    public void setTotalPurchases(int totalPurchases) { this.totalPurchases = totalPurchases; }
    public double getTotalSpent() { return totalSpent; }
    public void setTotalSpent(double totalSpent) { this.totalSpent = totalSpent; }
    public long getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return name + " (" + phone + ")";
    }
}