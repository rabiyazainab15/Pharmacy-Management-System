package com.pharmacy.models;

import java.io.Serializable;
import java.time.LocalDate;

public class Medicine implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int medicineId;
    private String name;
    private String category;
    private String manufacturer;
    private String batchNumber;
    private double purchasePrice;
    private double sellingPrice;
    private int quantity;
    private int reorderLevel;
    private LocalDate expiryDate;
    private int supplierId;
    private long createdAt;

    public Medicine(int medicineId, String name, String category, String manufacturer, 
                   String batchNumber, double purchasePrice, double sellingPrice, 
                   int quantity, int reorderLevel, LocalDate expiryDate, int supplierId) {
        this.medicineId = medicineId;
        this.name = name;
        this.category = category;
        this.manufacturer = manufacturer;
        this.batchNumber = batchNumber;
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.quantity = quantity;
        this.reorderLevel = reorderLevel;
        this.expiryDate = expiryDate;
        this.supplierId = supplierId;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and Setters
    public int getMedicineId() { return medicineId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public String getManufacturer() { return manufacturer; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }
    public String getBatchNumber() { return batchNumber; }
    public void setBatchNumber(String batchNumber) { this.batchNumber = batchNumber; }
    public double getPurchasePrice() { return purchasePrice; }
    public void setPurchasePrice(double purchasePrice) { this.purchasePrice = purchasePrice; }
    public double getSellingPrice() { return sellingPrice; }
    public void setSellingPrice(double sellingPrice) { this.sellingPrice = sellingPrice; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(int reorderLevel) { this.reorderLevel = reorderLevel; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }
    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
    public long getCreatedAt() { return createdAt; }

    public boolean isLowStock() {
        return quantity < reorderLevel;
    }

    public boolean isExpiringSoon() {
        return expiryDate.minusDays(30).isBefore(LocalDate.now());
    }

    @Override
    public String toString() {
        return name + " (" + batchNumber + ")";
    }
}