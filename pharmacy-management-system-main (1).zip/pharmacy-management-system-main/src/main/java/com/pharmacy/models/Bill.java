package com.pharmacy.models;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Bill implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int billId;
    private int customerId;
    private String customerName;
    private LocalDate billDate;
    private LocalTime billTime;
    private List<BillItem> items;
    private double subtotal;
    private double discount;
    private double total;
    private int userId;

    public Bill(int billId, int customerId, String customerName, int userId) {
        this.billId = billId;
        this.customerId = customerId;
        this.customerName = customerName;
        this.billDate = LocalDate.now();
        this.billTime = LocalTime.now();
        this.items = new ArrayList<>();
        this.subtotal = 0.0;
        this.discount = 0.0;
        this.total = 0.0;
        this.userId = userId;
    }

    // Getters and Setters
    public int getBillId() { return billId; }
    public int getCustomerId() { return customerId; }
    public String getCustomerName() { return customerName; }
    public LocalDate getBillDate() { return billDate; }
    public LocalTime getBillTime() { return billTime; }
    public List<BillItem> getItems() { return items; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }
    public double getTotal() { return total; }
    public int getUserId() { return userId; }

    public void addItem(BillItem item) {
        items.add(item);
        calculateTotal();
    }

    public void removeItem(int index) {
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            calculateTotal();
        }
    }

    public void calculateTotal() {
        subtotal = 0;
        for (BillItem item : items) {
            subtotal += item.getTotal();
        }
        total = subtotal - discount;
    }

    @Override
    public String toString() {
        return "Bill #" + billId + " - " + customerName + " (" + billDate + ")";
    }
}