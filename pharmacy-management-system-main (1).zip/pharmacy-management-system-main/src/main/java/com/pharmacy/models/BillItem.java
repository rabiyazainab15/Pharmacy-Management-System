package com.pharmacy.models;

import java.io.Serializable;

public class BillItem implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int medicineId;
    private String medicineName;
    private double unitPrice;
    private int quantity;
    private double total;

    public BillItem(int medicineId, String medicineName, double unitPrice, int quantity) {
        this.medicineId = medicineId;
        this.medicineName = medicineName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.total = unitPrice * quantity;
    }

    // Getters and Setters
    public int getMedicineId() { return medicineId; }
    public String getMedicineName() { return medicineName; }
    public double getUnitPrice() { return unitPrice; }
    public int getQuantity() { return quantity; }
    public double getTotal() { return total; }

    @Override
    public String toString() {
        return medicineName + " x" + quantity + " @ Rs." + unitPrice;
    }
}