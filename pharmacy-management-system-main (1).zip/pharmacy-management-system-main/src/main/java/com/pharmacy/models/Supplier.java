package com.pharmacy.models;

import java.io.Serializable;

public class Supplier implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int supplierId;
    private String companyName;
    private String contactPerson;
    private String phone;
    private String email;
    private String address;
    private long createdAt;

    public Supplier(int supplierId, String companyName, String contactPerson, 
                   String phone, String email, String address) {
        this.supplierId = supplierId;
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.createdAt = System.currentTimeMillis();
    }

    // Getters and Setters
    public int getSupplierId() { return supplierId; }
    public String getCompanyName() { return companyName; }
    public void setCompanyName(String companyName) { this.companyName = companyName; }
    public String getContactPerson() { return contactPerson; }
    public void setContactPerson(String contactPerson) { this.contactPerson = contactPerson; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public long getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return companyName + " (" + contactPerson + ")";
    }
}