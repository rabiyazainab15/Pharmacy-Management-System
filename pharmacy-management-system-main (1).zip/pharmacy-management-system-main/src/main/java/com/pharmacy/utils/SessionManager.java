package com.pharmacy.utils;

import com.pharmacy.models.User;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    private long sessionStartTime;
    private static final long SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

    private SessionManager() {
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void login(User user) {
        this.currentUser = user;
        this.sessionStartTime = System.currentTimeMillis();
    }

    public void logout() {
        this.currentUser = null;
        this.sessionStartTime = 0;
    }

    public User getCurrentUser() {
        if (isSessionValid()) {
            return currentUser;
        }
        return null;
    }

    public boolean isLoggedIn() {
        return currentUser != null && isSessionValid();
    }

    public boolean isAdmin() {
        return currentUser != null && currentUser.isAdmin();
    }

    private boolean isSessionValid() {
        if (currentUser == null) return false;
        return (System.currentTimeMillis() - sessionStartTime) < SESSION_TIMEOUT;
    }

    public long getSessionRemainingTime() {
        long elapsed = System.currentTimeMillis() - sessionStartTime;
        return SESSION_TIMEOUT - elapsed;
    }
}