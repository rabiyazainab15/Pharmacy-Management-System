package com.pharmacy.utils;

import javax.swing.*;
import java.awt.*;

public class UIUtils {
    
    public static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(Constants.NORMAL_FONT);
        button.setBackground(Constants.PRIMARY_COLOR);
        button.setForeground(Constants.WHITE);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(100, 35));
        return button;
    }

    public static JButton createSecondaryButton(String text) {
        JButton button = new JButton(text);
        button.setFont(Constants.NORMAL_FONT);
        button.setBackground(Constants.SECONDARY_COLOR);
        button.setForeground(Constants.WHITE);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(100, 35));
        return button;
    }

    public static JTextField createTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setFont(Constants.NORMAL_FONT);
        textField.setBorder(BorderFactory.createLineBorder(Constants.PRIMARY_COLOR));
        return textField;
    }

    public static JPasswordField createPasswordField(int columns) {
        JPasswordField passwordField = new JPasswordField(columns);
        passwordField.setFont(Constants.NORMAL_FONT);
        passwordField.setBorder(BorderFactory.createLineBorder(Constants.PRIMARY_COLOR));
        return passwordField;
    }

    public static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(Constants.NORMAL_FONT);
        label.setForeground(Constants.TEXT_COLOR);
        return label;
    }

    public static JLabel createTitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(Constants.TITLE_FONT);
        label.setForeground(Constants.PRIMARY_COLOR);
        return label;
    }

    public static JLabel createHeaderLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(Constants.HEADER_FONT);
        label.setForeground(Constants.PRIMARY_COLOR);
        return label;
    }

    public static void showErrorDialog(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void showSuccessDialog(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showWarningDialog(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }

    public static int showConfirmDialog(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Confirm", JOptionPane.YES_NO_OPTION);
    }

    public static void stylePanel(JPanel panel) {
        panel.setBackground(Constants.BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(Constants.PADDING, Constants.PADDING, 
                                                        Constants.PADDING, Constants.PADDING));
    }
}