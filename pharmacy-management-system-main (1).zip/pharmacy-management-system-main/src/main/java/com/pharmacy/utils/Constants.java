package com.pharmacy.utils;

import java.awt.*;

public class Constants {
    // Window Dimensions
    public static final int WINDOW_WIDTH = 1200;
    public static final int WINDOW_HEIGHT = 700;
    
    // Colors (Blue & White Theme)
    public static final Color PRIMARY_COLOR = new Color(41, 128, 185); // Blue
    public static final Color SECONDARY_COLOR = new Color(52, 152, 219); // Light Blue
    public static final Color BACKGROUND_COLOR = new Color(240, 245, 250); // Very Light Blue
    public static final Color TEXT_COLOR = new Color(44, 62, 80); // Dark Gray
    public static final Color ERROR_COLOR = new Color(231, 76, 60); // Red
    public static final Color SUCCESS_COLOR = new Color(39, 174, 96); // Green
    public static final Color WARNING_COLOR = new Color(241, 196, 15); // Yellow
    public static final Color WHITE = Color.WHITE;
    
    // Fonts
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font NORMAL_FONT = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 10);
    
    // Padding & Spacing
    public static final int PADDING = 10;
    public static final int SPACING = 5;
    public static final int BORDER_RADIUS = 5;
    
    // Messages
    public static final String LOGIN_TITLE = "Pharmacy Management System";
    public static final String APP_TITLE = "Pharmacy Management System";
    public static final String INVALID_CREDENTIALS = "Invalid username or password!";
    public static final String ACCOUNT_LOCKED = "Account locked! Try again after 5 minutes.";
    public static final String LOGIN_SUCCESS = "Login successful!";
    public static final String LOGOUT_SUCCESS = "Logged out successfully.";
    public static final String FIELD_REQUIRED = "This field is required!";
    public static final String INVALID_EMAIL = "Invalid email format!";
    public static final String INVALID_PHONE = "Invalid phone number!";
    public static final String INVALID_PRICE = "Invalid price format!";
    public static final String INVALID_QUANTITY = "Invalid quantity!";
    public static final String INSUFFICIENT_STOCK = "Insufficient stock available!";
    public static final String EXPIRY_WARNING = "Medicines expiring soon!";
    public static final String LOW_STOCK_WARNING = "Low stock alert!";
    
    // Database
    public static final String DB_NAME = "pharmacy.db";
    public static final String DB_USER = "admin";
    public static final String DB_PASSWORD = "admin";
}