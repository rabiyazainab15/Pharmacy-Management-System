package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class SupplierPanel extends JPanel {
    private JTable supplierTable;
    private JTextField searchField;
    private JButton addButton, editButton, deleteButton;

    public SupplierPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Supplier Management");
        add(titleLabel, BorderLayout.NORTH);

        // Toolbar
        JPanel toolbarPanel = new JPanel();
        toolbarPanel.setBackground(Constants.BACKGROUND_COLOR);
        toolbarPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        searchField = UIUtils.createTextField(20);
        JLabel searchLabel = UIUtils.createLabel("Search:");
        toolbarPanel.add(searchLabel);
        toolbarPanel.add(searchField);
        
        addButton = UIUtils.createButton("Add Supplier");
        editButton = UIUtils.createButton("Edit");
        deleteButton = UIUtils.createButton("Delete");
        
        toolbarPanel.add(addButton);
        toolbarPanel.add(editButton);
        toolbarPanel.add(deleteButton);

        add(toolbarPanel, BorderLayout.SOUTH);

        // Table
        DefaultTableModel model = new DefaultTableModel(
            new Object[][] {
                {1, "PharmaCorp", "Muhammad Hassan", "03001234567", "pharma@email.com"},
                {2, "MediSupply", "Ayesha Ahmed", "03009876543", "medi@email.com"},
                {3, "HealthFirst", "Ali Raza", "03005678901", "health@email.com"}
            },
            new String[] {"ID", "Company", "Contact Person", "Phone", "Email"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        supplierTable = new JTable(model);
        supplierTable.setFont(Constants.NORMAL_FONT);
        supplierTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(supplierTable);
        
        add(scrollPane, BorderLayout.CENTER);
    }
}