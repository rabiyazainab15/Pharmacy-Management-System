package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;
import com.pharmacy.utils.SessionManager;
import com.pharmacy.models.User;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private JLabel userLabel;
    private User currentUser;

    public MainFrame() {
        currentUser = SessionManager.getInstance().getCurrentUser();
        
        setTitle(Constants.APP_TITLE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
        setLocationRelativeTo(null);
        setResizable(true);
        
        initializeComponents();
    }

    private void initializeComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Constants.BACKGROUND_COLOR);

        // Header Panel
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // Body Panel with Sidebar and Content
        JPanel bodyPanel = new JPanel(new BorderLayout());
        bodyPanel.setBackground(Constants.BACKGROUND_COLOR);
        bodyPanel.add(createSidebarPanel(), BorderLayout.WEST);
        
        // Card Layout for switching panels
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setBackground(Constants.BACKGROUND_COLOR);
        
        // Add all panels
        cardPanel.add(new DashboardPanel(), "Dashboard");
        cardPanel.add(new InventoryPanel(), "Inventory");
        cardPanel.add(new SalesPanel(), "Sales");
        cardPanel.add(new CustomerPanel(), "Customers");
        cardPanel.add(new SupplierPanel(), "Suppliers");
        cardPanel.add(new ReportsPanel(), "Reports");
        cardPanel.add(new SettingsPanel(), "Settings");
        
        bodyPanel.add(cardPanel, BorderLayout.CENTER);
        mainPanel.add(bodyPanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Constants.PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel titleLabel = UIUtils.createTitleLabel("Pharmacy Management System");
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setBackground(Constants.PRIMARY_COLOR);
        
        userLabel = new JLabel("User: " + currentUser.getUsername() + " (" + currentUser.getRole() + ")");
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(Constants.NORMAL_FONT);
        rightPanel.add(userLabel);
        
        JButton logoutButton = UIUtils.createButton("Logout");
        logoutButton.addActionListener(e -> handleLogout());
        rightPanel.add(logoutButton);
        
        headerPanel.add(rightPanel, BorderLayout.EAST);
        return headerPanel;
    }

    private JPanel createSidebarPanel() {
        JPanel sidebarPanel = new JPanel();
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
        sidebarPanel.setBackground(Constants.SECONDARY_COLOR);
        sidebarPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        sidebarPanel.setPreferredSize(new Dimension(180, 0));

        JButton dashboardBtn = createNavButton("Dashboard", "Dashboard");
        JButton inventoryBtn = createNavButton("Inventory", "Inventory");
        JButton salesBtn = createNavButton("Sales", "Sales");
        JButton customerBtn = createNavButton("Customers", "Customers");
        JButton supplierBtn = createNavButton("Suppliers", "Suppliers");
        JButton reportsBtn = createNavButton("Reports", "Reports");
        JButton settingsBtn = createNavButton("Settings", "Settings");

        // Role-based access
        if (!currentUser.isAdmin()) {
            inventoryBtn.setEnabled(false);
            supplierBtn.setEnabled(false);
            settingsBtn.setEnabled(false);
        }

        sidebarPanel.add(Box.createVerticalStrut(10));
        sidebarPanel.add(dashboardBtn);
        sidebarPanel.add(Box.createVerticalStrut(5));
        sidebarPanel.add(inventoryBtn);
        sidebarPanel.add(Box.createVerticalStrut(5));
        sidebarPanel.add(salesBtn);
        sidebarPanel.add(Box.createVerticalStrut(5));
        sidebarPanel.add(customerBtn);
        sidebarPanel.add(Box.createVerticalStrut(5));
        sidebarPanel.add(supplierBtn);
        sidebarPanel.add(Box.createVerticalStrut(5));
        sidebarPanel.add(reportsBtn);
        sidebarPanel.add(Box.createVerticalStrut(5));
        sidebarPanel.add(settingsBtn);
        sidebarPanel.add(Box.createVerticalGlue());

        return sidebarPanel;
    }

    private JButton createNavButton(String text, String panelName) {
        JButton button = new JButton(text);
        button.setFont(Constants.NORMAL_FONT);
        button.setBackground(Constants.SECONDARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setMaximumSize(new Dimension(160, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(e -> cardLayout.show(cardPanel, panelName));
        return button;
    }

    private void handleLogout() {
        int result = UIUtils.showConfirmDialog(this, "Are you sure you want to logout?");
        if (result == JOptionPane.YES_OPTION) {
            SessionManager.getInstance().logout();
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            dispose();
        }
    }
}