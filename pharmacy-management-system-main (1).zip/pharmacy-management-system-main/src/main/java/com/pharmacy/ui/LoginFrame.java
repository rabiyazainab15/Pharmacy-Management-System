package com.pharmacy.ui;

import com.pharmacy.models.User;
import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;
import com.pharmacy.utils.ValidationUtils;
import com.pharmacy.utils.SessionManager;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton clearButton;
    private JLabel errorLabel;
    private JLabel attemptsLabel;
    
    private Map<String, Integer> failedAttempts = new HashMap<>();
    private Map<String, Long> lockedAccounts = new HashMap<>();

    public LoginFrame() {
        setTitle(Constants.LOGIN_TITLE);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setResizable(false);
        
        initializeComponents();
    }

    private void initializeComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(Constants.PRIMARY_COLOR);
        mainPanel.setLayout(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Constants.PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(30, 0, 20, 0));
        JLabel titleLabel = UIUtils.createTitleLabel("Pharmacy Management System");
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        // Form Panel
        JPanel formPanel = new JPanel();
        formPanel.setBackground(Color.WHITE);
        formPanel.setLayout(new GridLayout(5, 1, 0, 15));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Username
        JPanel usernamePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        usernamePanel.setBackground(Color.WHITE);
        usernamePanel.add(UIUtils.createLabel("Username:"));
        usernameField = UIUtils.createTextField(20);
        usernamePanel.add(usernameField);
        formPanel.add(usernamePanel);

        // Password
        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        passwordPanel.setBackground(Color.WHITE);
        passwordPanel.add(UIUtils.createLabel("Password:"));
        passwordField = UIUtils.createPasswordField(20);
        passwordPanel.add(passwordField);
        formPanel.add(passwordPanel);

        // Error Label
        errorLabel = new JLabel();
        errorLabel.setForeground(Constants.ERROR_COLOR);
        errorLabel.setFont(Constants.SMALL_FONT);
        formPanel.add(errorLabel);

        // Attempts Label
        attemptsLabel = new JLabel();
        attemptsLabel.setForeground(Constants.WARNING_COLOR);
        attemptsLabel.setFont(Constants.SMALL_FONT);
        formPanel.add(attemptsLabel);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setBackground(Color.WHITE);
        loginButton = UIUtils.createButton("Login");
        clearButton = UIUtils.createButton("Clear");
        buttonsPanel.add(loginButton);
        buttonsPanel.add(clearButton);
        formPanel.add(buttonsPanel);

        // Demo Credentials Panel
        JPanel demoPanel = new JPanel();
        demoPanel.setBackground(Color.WHITE);
        demoPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        demoPanel.setLayout(new BoxLayout(demoPanel, BoxLayout.Y_AXIS));
        
        JLabel demoLabel = UIUtils.createLabel("Demo Credentials:");
        demoLabel.setFont(Constants.SMALL_FONT);
        demoPanel.add(demoLabel);
        
        JLabel adminDemo = UIUtils.createLabel("Admin: admin / admin123");
        adminDemo.setFont(Constants.SMALL_FONT);
        demoPanel.add(adminDemo);
        
        JLabel staffDemo = UIUtils.createLabel("Staff: staff / staff123");
        staffDemo.setFont(Constants.SMALL_FONT);
        demoPanel.add(staffDemo);

        // Main Layout
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.add(formPanel);
        centerPanel.add(demoPanel);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Event Listeners
        loginButton.addActionListener(e -> handleLogin());
        clearButton.addActionListener(e -> clearFields());
        passwordField.addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (ValidationUtils.isEmpty(username) || ValidationUtils.isEmpty(password)) {
            errorLabel.setText("Username and password are required!");
            return;
        }

        // Check if account is locked
        if (isAccountLocked(username)) {
            errorLabel.setText(Constants.ACCOUNT_LOCKED);
            attemptsLabel.setText("");
            return;
        }

        // Verify credentials
        if (verifyCredentials(username, password)) {
            errorLabel.setText("");
            attemptsLabel.setText("");
            failedAttempts.remove(username);
            
            // Create user session
            User user = createUser(username, password);
            SessionManager.getInstance().login(user);
            
            // Open MainFrame
            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
            dispose();
        } else {
            handleFailedAttempt(username);
        }
    }

    private boolean verifyCredentials(String username, String password) {
        // Demo credentials
        if (username.equals("admin") && password.equals("admin123")) {
            return true;
        }
        if (username.equals("staff") && password.equals("staff123")) {
            return true;
        }
        return false;
    }

    private User createUser(String username, String password) {
        String role = username.equals("admin") ? "Admin" : "Staff";
        return new User(1, username, ValidationUtils.hashPassword(password), role);
    }

    private void handleFailedAttempt(String username) {
        int attempts = failedAttempts.getOrDefault(username, 0) + 1;
        failedAttempts.put(username, attempts);

        if (attempts >= 3) {
            lockedAccounts.put(username, System.currentTimeMillis());
            errorLabel.setText(Constants.ACCOUNT_LOCKED);
        } else {
            errorLabel.setText(Constants.INVALID_CREDENTIALS);
            attemptsLabel.setText("Attempts: " + attempts + "/3");
        }
    }

    private boolean isAccountLocked(String username) {
        if (!lockedAccounts.containsKey(username)) {
            return false;
        }
        long lockTime = lockedAccounts.get(username);
        long currentTime = System.currentTimeMillis();
        long lockDuration = 5 * 60 * 1000; // 5 minutes

        if (currentTime - lockTime > lockDuration) {
            lockedAccounts.remove(username);
            failedAttempts.remove(username);
            return false;
        }
        return true;
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        errorLabel.setText("");
        usernameField.requestFocus();
    }
}