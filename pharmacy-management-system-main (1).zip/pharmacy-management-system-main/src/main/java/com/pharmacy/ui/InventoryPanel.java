package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class InventoryPanel extends JPanel {
    private JTable medicineTable;
    private JTextField searchField;
    private JButton addButton, editButton, deleteButton;

    public InventoryPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Inventory Management");
        add(titleLabel, BorderLayout.NORTH);

        // Toolbar
        JPanel toolbarPanel = new JPanel();
        toolbarPanel.setBackground(Constants.BACKGROUND_COLOR);
        toolbarPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        searchField = UIUtils.createTextField(20);
        JLabel searchLabel = UIUtils.createLabel("Search:");
        toolbarPanel.add(searchLabel);
        toolbarPanel.add(searchField);
        
        addButton = UIUtils.createButton("Add Medicine");
        editButton = UIUtils.createButton("Edit");
        deleteButton = UIUtils.createButton("Delete");
        
        toolbarPanel.add(addButton);
        toolbarPanel.add(editButton);
        toolbarPanel.add(deleteButton);

        add(toolbarPanel, BorderLayout.SOUTH);

        // Table
        DefaultTableModel model = new DefaultTableModel(
            new Object[][] {
                {1, "Aspirin", "Painkiller", "A123", "100", "150", "50", "2026-12-31"},
                {2, "Paracetamol", "Painkiller", "P456", "80", "120", "80", "2026-11-15"},
                {3, "Vitamin C", "Supplement", "V789", "50", "90", "150", "2027-06-30"}
            },
            new String[] {"ID", "Name", "Category", "Batch", "Cost", "Price", "Qty", "Expiry"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        medicineTable = new JTable(model);
        medicineTable.setFont(Constants.NORMAL_FONT);
        medicineTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(medicineTable);
        
        add(scrollPane, BorderLayout.CENTER);
    }
}