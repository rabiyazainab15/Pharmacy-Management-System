package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class CustomerPanel extends JPanel {
    private JTable customerTable;
    private JTextField searchField;
    private JButton addButton, viewButton;

    public CustomerPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Customer Management");
        add(titleLabel, BorderLayout.NORTH);

        // Toolbar
        JPanel toolbarPanel = new JPanel();
        toolbarPanel.setBackground(Constants.BACKGROUND_COLOR);
        toolbarPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        searchField = UIUtils.createTextField(20);
        JLabel searchLabel = UIUtils.createLabel("Search:");
        toolbarPanel.add(searchLabel);
        toolbarPanel.add(searchField);
        
        addButton = UIUtils.createButton("Add Customer");
        viewButton = UIUtils.createButton("View History");
        
        toolbarPanel.add(addButton);
        toolbarPanel.add(viewButton);

        add(toolbarPanel, BorderLayout.SOUTH);

        // Table
        DefaultTableModel model = new DefaultTableModel(
            new Object[][] {
                {1, "Ahmed Ali", "03001234567", "ahmed@email.com", "5", "12,500"},
                {2, "Fatima Khan", "03009876543", "fatima@email.com", "3", "8,200"},
                {3, "Hassan Ahmed", "03005678901", "hassan@email.com", "8", "25,100"}
            },
            new String[] {"ID", "Name", "Phone", "Email", "Purchases", "Total Spent"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        customerTable = new JTable(model);
        customerTable.setFont(Constants.NORMAL_FONT);
        customerTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(customerTable);
        
        add(scrollPane, BorderLayout.CENTER);
    }
}