package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ReportsPanel extends JPanel {
    private JComboBox<String> reportTypeCombo;
    private JTable reportTable;

    public ReportsPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Reports");
        add(titleLabel, BorderLayout.NORTH);

        // Toolbar
        JPanel toolbarPanel = new JPanel();
        toolbarPanel.setBackground(Constants.BACKGROUND_COLOR);
        toolbarPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JLabel reportLabel = UIUtils.createLabel("Select Report Type:");
        reportTypeCombo = new JComboBox<>(new String[] {
            "Sales Report",
            "Inventory Report",
            "Expiry Report",
            "Low Stock Report"
        });
        
        JButton generateBtn = UIUtils.createButton("Generate");
        JButton exportBtn = UIUtils.createButton("Export PDF");
        
        toolbarPanel.add(reportLabel);
        toolbarPanel.add(reportTypeCombo);
        toolbarPanel.add(generateBtn);
        toolbarPanel.add(exportBtn);

        add(toolbarPanel, BorderLayout.SOUTH);

        // Table
        DefaultTableModel model = new DefaultTableModel(
            new Object[][] {
                {"2026-01-10", "Aspirin", "50", "5000"},
                {"2026-01-10", "Paracetamol", "30", "3600"},
                {"2026-01-09", "Vitamin C", "75", "6750"}
            },
            new String[] {"Date", "Medicine", "Quantity", "Amount"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        reportTable = new JTable(model);
        reportTable.setFont(Constants.NORMAL_FONT);
        reportTable.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(reportTable);
        
        add(scrollPane, BorderLayout.CENTER);
    }
}