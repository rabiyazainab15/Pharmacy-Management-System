package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import java.awt.*;

public class DashboardPanel extends JPanel {
    public DashboardPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Dashboard");
        add(titleLabel, BorderLayout.NORTH);

        // Content Panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(2, 2, 20, 20));
        contentPanel.setBackground(Constants.BACKGROUND_COLOR);

        // Statistics Cards
        contentPanel.add(createStatCard("Total Medicines", "156", Constants.PRIMARY_COLOR));
        contentPanel.add(createStatCard("Low Stock Items", "12", Constants.WARNING_COLOR));
        contentPanel.add(createStatCard("Expiring Soon", "8", Constants.ERROR_COLOR));
        contentPanel.add(createStatCard("Today's Sales", "Rs. 15,420", Constants.SUCCESS_COLOR));

        add(contentPanel, BorderLayout.CENTER);
    }

    private JPanel createStatCard(String title, String value, Color bgColor) {
        JPanel card = new JPanel(new GridLayout(2, 1));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(bgColor, 2));
        card.setPreferredSize(new Dimension(200, 100));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(Constants.NORMAL_FONT);
        titleLabel.setForeground(Constants.TEXT_COLOR);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(Constants.TITLE_FONT);
        valueLabel.setForeground(bgColor);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);

        card.add(titleLabel);
        card.add(valueLabel);

        return card;
    }
}