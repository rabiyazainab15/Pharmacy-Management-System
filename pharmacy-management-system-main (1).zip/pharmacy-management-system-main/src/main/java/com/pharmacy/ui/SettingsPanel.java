package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import java.awt.*;

public class SettingsPanel extends JPanel {
    private JTextField currentPasswordField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmPasswordField;
    private JButton changePasswordBtn;

    public SettingsPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Settings");
        add(titleLabel, BorderLayout.NORTH);

        // Settings Panel
        JPanel settingsPanel = new JPanel();
        settingsPanel.setLayout(new BoxLayout(settingsPanel, BoxLayout.Y_AXIS));
        settingsPanel.setBackground(Color.WHITE);
        settingsPanel.setBorder(BorderFactory.createLineBorder(Constants.PRIMARY_COLOR));

        // Change Password Section
        JLabel changePassLabel = UIUtils.createHeaderLabel("Change Password");
        settingsPanel.add(changePassLabel);
        settingsPanel.add(Box.createVerticalStrut(15));

        // Current Password
        JPanel currentPassPanel = new JPanel();
        currentPassPanel.setBackground(Color.WHITE);
        currentPassPanel.add(UIUtils.createLabel("Current Password:"));
        currentPasswordField = UIUtils.createTextField(20);
        currentPassPanel.add(currentPasswordField);
        settingsPanel.add(currentPassPanel);

        settingsPanel.add(Box.createVerticalStrut(10));

        // New Password
        JPanel newPassPanel = new JPanel();
        newPassPanel.setBackground(Color.WHITE);
        newPassPanel.add(UIUtils.createLabel("New Password:"));
        newPasswordField = UIUtils.createPasswordField(20);
        newPassPanel.add(newPasswordField);
        settingsPanel.add(newPassPanel);

        settingsPanel.add(Box.createVerticalStrut(10));

        // Confirm Password
        JPanel confirmPassPanel = new JPanel();
        confirmPassPanel.setBackground(Color.WHITE);
        confirmPassPanel.add(UIUtils.createLabel("Confirm Password:"));
        confirmPasswordField = UIUtils.createPasswordField(20);
        confirmPassPanel.add(confirmPasswordField);
        settingsPanel.add(confirmPassPanel);

        settingsPanel.add(Box.createVerticalStrut(20));

        // Change Password Button
        changePasswordBtn = UIUtils.createButton("Change Password");
        settingsPanel.add(changePasswordBtn);
        settingsPanel.add(Box.createVerticalGlue());

        add(settingsPanel, BorderLayout.CENTER);
    }
}