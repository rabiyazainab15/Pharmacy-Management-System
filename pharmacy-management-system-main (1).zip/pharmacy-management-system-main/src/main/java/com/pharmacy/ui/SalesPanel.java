package com.pharmacy.ui;

import com.pharmacy.utils.Constants;
import com.pharmacy.utils.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class SalesPanel extends JPanel {
    private JTextField medicineSearchField;
    private JTable cartTable;
    private JLabel totalLabel;
    private JTextField customerNameField;
    private JTextField discountField;

    public SalesPanel() {
        setLayout(new BorderLayout());
        setBackground(Constants.BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        initializeComponents();
    }

    private void initializeComponents() {
        // Title
        JLabel titleLabel = UIUtils.createTitleLabel("Sales & Billing");
        add(titleLabel, BorderLayout.NORTH);

        // Main Content Panel
        JPanel contentPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        contentPanel.setBackground(Constants.BACKGROUND_COLOR);

        // Left Panel - Search & Cart
        JPanel leftPanel = new JPanel(new BorderLayout(0, 10));
        leftPanel.setBackground(Constants.BACKGROUND_COLOR);

        // Search
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(Constants.BACKGROUND_COLOR);
        searchPanel.add(UIUtils.createLabel("Search Medicine:"));
        medicineSearchField = UIUtils.createTextField(20);
        searchPanel.add(medicineSearchField);
        JButton addToCartBtn = UIUtils.createButton("Add");
        searchPanel.add(addToCartBtn);
        leftPanel.add(searchPanel, BorderLayout.NORTH);

        // Cart Table
        DefaultTableModel cartModel = new DefaultTableModel(
            new Object[][] {
                {"Aspirin", "100", "2", "200"}
            },
            new String[] {"Medicine", "Price", "Qty", "Total"}
        ) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        cartTable = new JTable(cartModel);
        cartTable.setFont(Constants.NORMAL_FONT);
        cartTable.setRowHeight(25);
        JScrollPane cartScroll = new JScrollPane(cartTable);
        leftPanel.add(cartScroll, BorderLayout.CENTER);

        // Right Panel - Billing
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(BorderFactory.createLineBorder(Constants.PRIMARY_COLOR));

        rightPanel.add(Box.createVerticalStrut(10));
        rightPanel.add(UIUtils.createHeaderLabel("Bill Details"));
        rightPanel.add(Box.createVerticalStrut(15));

        // Customer Name
        JPanel customerPanel = new JPanel();
        customerPanel.setBackground(Color.WHITE);
        customerPanel.add(UIUtils.createLabel("Customer Name:"));
        customerNameField = UIUtils.createTextField(20);
        customerPanel.add(customerNameField);
        rightPanel.add(customerPanel);

        rightPanel.add(Box.createVerticalStrut(10));

        // Discount
        JPanel discountPanel = new JPanel();
        discountPanel.setBackground(Color.WHITE);
        discountPanel.add(UIUtils.createLabel("Discount (%):"));
        discountField = UIUtils.createTextField(5);
        discountPanel.add(discountField);
        rightPanel.add(discountPanel);

        rightPanel.add(Box.createVerticalStrut(20));

        // Subtotal
        JPanel subtotalPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        subtotalPanel.setBackground(Color.WHITE);
        subtotalPanel.add(UIUtils.createLabel("Subtotal:"));
        JLabel subtotalValueLabel = UIUtils.createLabel("Rs. 200");
        subtotalPanel.add(subtotalValueLabel);
        rightPanel.add(subtotalPanel);

        // Total
        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        totalPanel.setBackground(Color.WHITE);
        totalPanel.add(UIUtils.createLabel("Total:"));
        totalLabel = UIUtils.createHeaderLabel("Rs. 200");
        totalPanel.add(totalLabel);
        rightPanel.add(totalPanel);

        rightPanel.add(Box.createVerticalGlue());

        // Generate Bill Button
        JButton generateBillBtn = UIUtils.createButton("Generate Bill");
        rightPanel.add(generateBillBtn);
        rightPanel.add(Box.createVerticalStrut(10));

        contentPanel.add(leftPanel);
        contentPanel.add(rightPanel);
        add(contentPanel, BorderLayout.CENTER);
    }
}