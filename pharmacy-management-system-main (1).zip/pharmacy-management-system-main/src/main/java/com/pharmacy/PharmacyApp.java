package com.pharmacy;

import com.pharmacy.ui.LoginFrame;
import javax.swing.*;

public class PharmacyApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}